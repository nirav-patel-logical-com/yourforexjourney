<?php
/**
 * @package 	WordPress
 * @subpackage 	Startup Company Child
 * @version		1.0.0
 * 
 * Child Theme Functions File
 * Created by CMSMasters
 * 
 */


function startup_company_child_enqueue_styles() {
    wp_enqueue_style('startup-company-child-style', get_stylesheet_uri(), array('startup-company-style'), '1.0.0', 'screen, print');
}

add_action('wp_enqueue_scripts', 'startup_company_child_enqueue_styles', 11);
?>